# <p align="center" style="color:#cb3349" >📡 سـورس رامـبـو 📡

# <p align="center" style="color: #14635c;" > TH3VICTORY حصريا من قناة  ⭐️



# <p align="center" style="color: #14635c;" >📈 مـمــيــزات الــسـورس 📈
 
<br>🚴🏼¦ خفيف وسريع <br>
<br>⚙️¦ ادخال المعلومات من الترمنال وتشغيل مباشر <br>
<br>🔅¦ يقوم بتشغيل نفسه عبر السكرين تلقائيا<br>
<br>💢¦ يعرض لك قائمه المجموعات بملف خارجي بصيغه HTML <br>
<br>📮¦ امر نسخه احتياطيه للمجموعات : للاحتفاض بمجموعاتك بامان<br>
<br>📫¦ يدعم التحديثات بشكل دوري لضمان حل مشاكل ان وجدت . <br>
<br>🃏¦ والـكـثـيــر ... <br>


# <p align="center"> كود تنصيب السورس 🖇

<br>` git clone https://github.com/ramizob3a/RAMBO && cd RAMBO && chmod +x install.sh && ./install.sh `<br>


# <p align="center"> بعد انتهاء عمليه تثبيت السورس 🚸



 <br> 📊¦ تظهر لك ادخل توكن البوت تقوم بادخال التوكن ثم انتر
 <br> ⚙️¦ بعدها ايدي المطور تقوم بادخاله ثم انتر
 <br> ✅¦ واخيرا رح يشتغل السورس وبالتوفيق تلقائيا ...

<br>
 <p align="center"> :: كود تشغيل السورس | لتشغيل السورس يدوي 📛
 
افتح ترمنال جديد ثم تدخل الكود الاتي <br>
 <br>  `./RAMBO/rm`

#  💬¦ للمشاكل والاسفسار والاقتراحات :
  
  [ رامي || الْٰـدِٰ૭لْٰــة ](https://telegram.me/RAMBO_SYR) <br>
  
  [ تواصل للمحظورين٠](https://telegram.me/th3victory_bot) <br>
  
  
[TH3VICTORY](https://telegram.me/TH3VICTORY) <br>
  
# <p align="center"> كروب دعم السورس للتكلم حول المشاكل

  # <p align="center">[اضــغــط هــنــا للــدخــول للمجموعةة🌿](https://t.me/joinchat/AAAAAERvnA8LPw0JKQdO1A)
  
